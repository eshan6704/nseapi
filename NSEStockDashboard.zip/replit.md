# NSE Stock Dashboard

## Overview
A FastAPI + Gradio web application for viewing NSE (National Stock Exchange of India) stock and index data. The app fetches live market data, displays charts, tables, and various financial metrics.

## Recent Changes
- 2026-03-25: Removed Gradio; app is now pure FastAPI serving index.html at `/`
- 2026-02-18: Initial Replit setup - configured ports, paths, and dependencies

## Project Architecture
- **Framework**: FastAPI backend serving index.html at `/`
- **Language**: Python 3.11
- **Key Dependencies**: yfinance, pandas, numpy, plotly, TA-Lib, beautifulsoup4, boto3
- **Port**: 5000

### Directory Structure
```
app/
├── app.py              # FastAPI app entry point
├── common.py           # Shared HTML/formatting utilities
├── gradio_ui.py        # Gradio dashboard interface
├── router/
│   └── router.py       # API routes (/file, /api/health)
├── nse/                # NSE data fetching modules
├── yohoofinance/       # Yahoo Finance data modules
├── screener/           # Stock screener functionality
├── technical/          # Technical analysis indicators
├── svgchart/           # SVG chart generation
├── blackblaze/         # Backblaze storage integration
└── persist/            # Data persistence
```

### Data Storage
- Files cached in `/home/runner/workspace/data/files/`
- Uses filename convention: `@mode@req_type@name[@enddate@startdate@suffix].html`

### API Endpoints
- `GET /api/health` - Health check
- `GET /file?name=<filename>&force=<bool>` - Fetch/cache market data

## User Preferences
- None recorded yet
